#define USE_NATIVE_LANGUAGE_SUPPORT 1
/* #undef HAVE_MALLOC_H */
/* #undef HAVE_SYS_MOUNT_H */
/* #undef HAVE_STDINT_H */
#define HAVE_API_ANDROID 1
/* #undef HAVE_API_WIN32_BASE */
/* #undef HAVE_API_WIN32 */
/* #undef HAVE_API_WIN32_CE */
/* #undef HAVE_GLIB */
/* #undef HAVE_GMODULE */
#define HAVE_GETCWD 1
#define CACHE_SIZE (20*1024*1024)
#define AVOID_FLOAT 1
/* #undef AVOID_UNALIGNED */
#define USE_LIBGNUINTL 1
/* #undef HAVE_BYTESWAP_H */
/* Versions */
#define PACKAGE_VERSION "0.5.0"
#define PACKAGE_NAME "navit-svn"
#define PACKAGE "navit"
#define LOCALEDIR "share/locale/locale"

/* #undef HAVE_LIBCRYPTO */

/* #undef HAVE_ZLIB */

#define USE_ROUTING 1

/* #undef HAVE_GTK2 */

/* #undef HAVE_FONTCONFIG */

#define USE_PLUGINS 1

/* #undef SDL_TTF */

/* #undef SDL_IMAGE */

/* #undef HAVE_QT_SVG */

/* #undef HAVE_UNISTD_H */

/* #undef DBUS_USE_SYSTEM_BUS */

/* #undef HAVE_SOCKET */
#define HAVE_SNPRINTF 1
/* #undef HAVE_DECL__SNPRINTF */

/* #undef HAVE_WINSOCK */

#define HAVE_MEMALIGN 1

#define HAVE_POSIX_MEMALIGN 1

#define HAVE_VALLOC 1

/* #undef HAVE_LC_MESSAGES */

/* #undef HAVE_SYS_TIME_H */

#define HAVE_POPEN 1

/* #undef HAVE_GETOPT_H */
#define HAVE_GETTIMEOFDAY 1

/* #undef HAVE__ATOI64 */

/* #undef HAVE_STRING_H */

/* #undef EZXML_NOMMAP */

/* #undef HAVE_STPCPY */

#define HAVE_SBRK 1

/* #undef HAVE_PRAGMA_PACK */

#define HAVE_GETDELIM 1

#define HAVE_GETLINE 1

#define HAVE_FSYNC 1

/* #undef HAVE_ENDIAN_H */

#define HAVE_FREEIMAGE 1

/* #undef USE_OPENGLES */

/* #undef USE_OPENGLES2 */

/* #undef HAVE_SHMEM */

/* #undef HAVE_IMLIB2 */
